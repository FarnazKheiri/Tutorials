import java.util.*;

public class Guess {
    public static void main(String[] args)
    {
        int numToGuess;
        int guess;
        int tooHigh = 0;
        int tooLow = 0;
        int totalGuesses = 0;

        Scanner scan = new Scanner(System.in);
        Random generator = new Random();
        numToGuess = generator.nextInt(10) + 1;

        System.out.println("Please enter a guess");
        guess = scan.nextInt();
        while(guess != numToGuess)
        {
            if (guess > numToGuess)
            {
                System.out.println("Your guess is too high, please guess again");
                tooHigh++;
                totalGuesses++;
                guess = scan.nextInt();
            }
            else if (guess < numToGuess)
            {
                System.out.println("Your guess is too low, please guess again");
                tooLow++;
                totalGuesses++;
                guess = scan.nextInt();
            }
        }
        totalGuesses++;
        System.out.println("Good job! Your guess is correct. You took " + totalGuesses + " guesses");
        System.out.println("You guessed " + tooHigh + " times too high");
        System.out.println("You guessed " + tooLow + " times too low");

    }

}

