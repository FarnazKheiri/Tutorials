import java.util.*;
public class PowersOf2 {
    public static void main(String[] args)
    {
        int numPowersOf2 = 5;
        int nextPowerOf2 = 1;
        int exponent;
        Scanner scan = new Scanner(System.in);
        System.out.println("How many powers of 2 would you like printed?");
        numPowersOf2 = scan.nextInt();
        //Complete this part below:
        exponent = 0;
        System.out.println("Here are the first " + numPowersOf2 + " powers of 2:");
        while(exponent < numPowersOf2)
        {
            System.out.println("2^" + exponent + " = " + nextPowerOf2);
            exponent++;
            nextPowerOf2 *= 2;
        }
    }

}
