import java.util.*;

public class Count {
    public static void main(String[] args)
    {
        String phrase;
        int countBlank;
        int length;
        int countA;
        int countE;
        int countS;
        int countT;
        char ch;
        //Initializing this prompt to an empty space so that it can enter the main while loop until the user wants to quit
        String prompt = " ";
        Scanner scan = new Scanner(System.in);
        System.out.println();
        System.out.println("Character Counter");
        System.out.println();
        while (!prompt.equals("quit"))
        {
            System.out.print("Enter a sentence or phrase: ");
            //Find string length
            phrase = scan.nextLine();
            //initialize counts, resetting these values each loop iteration so that when user restarts, the counters are accurate
            length = phrase.length();
            countA = 0;
            countE = 0;
            countS = 0;
            countT = 0;
            countBlank = 0;
            for(int i = 0; i < length; i++)
            {
                ch = phrase.charAt(i);
                switch (ch) {
                    case 'a':
                    case 'A':
                        countA++;
                        break;
                    case 'e':
                    case 'E':
                        countE++;
                        break;
                    case 's':
                    case 'S':
                        countS++;
                        break;
                    case 't':
                    case 'T':
                        countT++;
                        break;
                    case ' ':
                        countBlank++;
                        break;
                }
            }
            System.out.println("Number of blank spaces: " + countBlank);
            System.out.println("Number of A's: " + countA);
            System.out.println("Number of E's: " + countE);
            System.out.println("Number of S's: " + countS);
            System.out.println("Number of T's: " + countT);
            System.out.println("If you would like to quit this program, type 'quit' otherwise, click enter");
            prompt = scan.nextLine();
            if (prompt.equals("quit"))
            {
                prompt = "quit";
            }
        }
        System.out.println("Thank you for using the count application. Now exiting.");
        System.exit(0);
    }
}
