import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String phrase;
        while (true){
            System.out.println("Enter your phrase or enter quit if you do not wish to continue: ");
            phrase = sc.nextLine();
            if(phrase.equals("quit")) break;
            int countA=0;
            int countE=0;
            int countS=0;
            int countT=0;
            for (int i = 0; i < phrase.length(); i++) {
                switch (phrase.charAt(i)){
                    case 'a':
                    case 'A': countA++;
                        break;
                    case 'e':
                    case 'E': countE++;
                        break;
                    case 's':
                    case 'S': countS++;
                        break;
                    case 't':
                    case 'T': countT++;
                        break;
                }
            }
            System.out.println("Number of A: "+countA);
            System.out.println("Number of E: "+countE);
            System.out.println("Number of S: "+countS);
            System.out.println("Number of T: "+countT);

        }

    }
}
