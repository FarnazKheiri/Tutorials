import java.util.Scanner;

public class Powers0f2{
    public static void main (String [] args){
        int numPowers0f2;
        int nextPower0f2 = 1;
        int exponent = 0;

        Scanner scan  = new Scanner (System.in);

        System.out.println( "How many powers of 2 would you like printed?");
        numPowers0f2 = scan.nextInt ();

        //print a message saying how many powers of 2 will be printed /initialize exponent -- the first thing printed is 2 to the what?
        System.out.println("Here are the first " + numPowers0f2 + " power of 2");

        while (exponent < numPowers0f2){
            System.out.println("2^" + exponent + " = " + nextPower0f2);
            //find next power of 2 - - how do you get this from the last one?
            nextPower0f2 *= 2;

            //increment exponent
            exponent++;
        }
    }
}

