import java.util.Scanner;
import java.util.Random;

public class Guess {
    public static void main(String[] args) {
        // Create a random number generator
        Random random = new Random();
        int numToGuess = random.nextInt(10) + 1; // Generates a random number between 1 and 10

        // Initialize variables for tracking guesses, too high, and too low counts
        int guess;
        int tooHighCount = 0;
        int tooLowCount = 0;

        // Create a Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Main game loop
        while (true) {
            // Ask the user to guess the number
            System.out.print("Guess a number between 1 and 10: ");
            guess = scanner.nextInt();
            guess++;

            // Check if the user's guess is correct
            if (guess == numToGuess) {
                System.out.println("Congratulations! You guessed the correct number in " + numToGuess + " guesses.");
                System.out.println("Too high guesses: " + tooHighCount);
                System.out.println("Too low guesses: " + tooLowCount);
                break; // Exit the loop if the guess is correct
            } else if (guess > numToGuess) {
                System.out.println("Too high. Try again.");
                tooHighCount++;
            } else {
                System.out.println("Too low. Try again.");
                tooLowCount++;
                }
            }

        // Close the scanner
        scanner.close();
        }
}

