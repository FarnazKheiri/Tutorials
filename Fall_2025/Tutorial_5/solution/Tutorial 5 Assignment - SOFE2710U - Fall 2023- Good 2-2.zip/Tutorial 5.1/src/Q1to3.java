import java.util.Scanner;

public class Q1to3 {
    // Q1) Average of two integers
    public static double average(int num1, int num2) {
        return (num1 + num2) / 2.0;
    }
    // Q2) Average of three integers
    public static double average(int num1, int num2, int num3) {
        return (num1 + num2 + num3) / 3.0;
    }
    // Q3) Average of four integers
    public static double average(int num1, int num2, int num3, int num4) {
        return (num1 + num2 + num3 + num4) / 4.0;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        // Average for two numbers
        System.out.print("Number 1: ");
        int num1 = scan.nextInt();
        System.out.print("Number 2: ");
        int num2 = scan.nextInt();
        System.out.println("Average of two numbers: " + average(num1, num2));

        // Average for three numbers
        System.out.print("Number 3: ");
        int num3 = scan.nextInt();
        System.out.println("Average of three numbers: " + average(num1, num2, num3));

        // Average for four numbers
        System.out.print("Number 4: ");
        int num4 = scan.nextInt();
        System.out.println("Average of four numbers: " + average(num1, num2, num3, num4));

        scan.close();
    }
}