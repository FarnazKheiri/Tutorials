//Question 4

import java.util.Scanner;

public class Main
{
    public interface Complexity
    {
        public void setComplexity (int complexity);
        public int getComplexity();
    }
    public static class Question implements Complexity
    {
        private String question, answer;
        private int complexityLevel;

        //-----------------------------------------------------------------
        //  Sets up the question with a default complexity.
        //-----------------------------------------------------------------
        public Question (String query, String result)
        {
            question = query;
            answer = result;
            complexityLevel = 1;
        }
        public void setComplexity (int level)
        {
            complexityLevel = level;
        }

        //-----------------------------------------------------------------
        //  Returns the complexity level for this question.
        //-----------------------------------------------------------------
        public int getComplexity()
        {
            return complexityLevel;
        }


        //-----------------------------------------------------------------
        //  Returns the question.
        //-----------------------------------------------------------------
        public String getQuestion()
        {
            return question;
        }

        //-----------------------------------------------------------------
        //  Returns the answer to this question.
        //-----------------------------------------------------------------
        public String getAnswer()
        {
            return answer;
        }

        //-----------------------------------------------------------------
        //  Returns true if the candidate answer matches the answer.
        //-----------------------------------------------------------------
        public boolean answerCorrect (String candidateAnswer)
        {
            return answer.equals(candidateAnswer);
        }

        //-----------------------------------------------------------------
        //  Returns this question (and its answer) as a string.
        //-----------------------------------------------------------------
        public String toString()
        {
            return question + "\n" + answer;
        }
    }

    private static Scanner scan = new Scanner(System.in);

    public static void main (String[] args)
    {
        Question q1 = new Question("Write a method called average that accepts two integer parameters and returns their average as a floating point value.", "public double average(int num1, int num2) { return(num1 + num2) / 2.0; }");
        q1.setComplexity(1);

        Question q2 = new Question("Overload the average method of question 1 such that if three integers are provided as parameters, the method returns the average of all three.", "public double average(int num1, int num2, int num3) { return (num1 + num2 + num3) / 3.0; }");
        q2.setComplexity(2);

        Question q3 = new Question("Overload the average method of question 1 to accept four integer parameters and return their average.", "public double average(int num1, int num2, int num3, int num4) { return (num1 + num2 + num3 + num4) / 4.0; }");
        q3.setComplexity(3);

        askQuestion(q1);
        askQuestion(q2);
        askQuestion(q3);
    }

    public static void askQuestion(Question q)
    {
        System.out.println(q.getQuestion());
        System.out.println(" (Level: " + q.getComplexity() + ")");

        String possible = scan.nextLine();

        if (q.answerCorrect(possible))
            System.out.println("Correct");
        else
            System.out.println("No, the answer is " + q.getAnswer());
    }
}
