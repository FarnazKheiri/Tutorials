//********************************************************************
//  MiniQuiz.java       Author: Lewis/Loftus
//
//  Demonstrates the use of a class that implements an interface.
//********************************************************************

import java.util.Scanner;

public class MiniQuiz {
   private static Scanner scan = new Scanner(System.in);
   //-----------------------------------------------------------------
   //  Presents a short quiz.
   //-----------------------------------------------------------------
   public static void askQuestion(Question q) {
      String answer;
      System.out.println(q.getQuestion());
      System.out.println("Level: " + q.getComplexity());
      answer = scan.nextLine();
      if (q.answerCorrect(answer))
         System.out.println("Correct");
      else
         System.out.println("No, the answer is: " + q.getAnswer());
   }
   public static void main (String[] args) {
      Question q1, q2, q;
      Scanner scan = new Scanner(System.in);

      q1 = new Question("What is your school name?", "Ontario Tech University");
      q1.setComplexity(10);
      q2 = new Question("What is your program?", "Software Engineering");
      q2.setComplexity(5);
      MiniQuiz.askQuestion(q1);
      MiniQuiz.askQuestion(q2);
   }
}
