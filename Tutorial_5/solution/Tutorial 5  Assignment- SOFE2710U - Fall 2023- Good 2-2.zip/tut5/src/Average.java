public class Average {
    void sum (int a, int b){
        System.out.println("Sum: "+ (a+b));
    }
    void sum (float a, float b, float c){
        System.out.println("Sum: "+ Math.ceil((a+b+c)));
    }
    void sum (int a, int b, int c, int d){
        System.out.println("Sum: "+ (a+b+c+d));
    }
    public static void main(String[] args){
        Average avg = new Average();
        avg.sum(5,19);
        avg.sum(5.2f,19.4f,15.1f);
        avg.sum(5,19,15,8);
    }
}
